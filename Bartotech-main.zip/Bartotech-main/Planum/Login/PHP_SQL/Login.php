<?php
session_start();
$conexão=mysqli_connect('localhost','root','','Bartotech');

$email=$_POST['email'];
$senha=$_POST['senha'];

if(!$conexão){
    die("Erro na conexão :(");
}

$sql = "SELECT * FROM cadastro WHERE email = '$email' AND senha = '$senha'";
$resultado = mysqli_query($conexão, $sql);

//resumidamente é um sistema de erros
   //testa se há 1 ou mais "contas" com esse email/senha
if (mysqli_num_rows($resultado) > 0) {
    $Pinkman=mysqli_fetch_assoc($resultado);
    $_SESSION['logado']=true;
    $_SESSION['id']=$Pinkman['id'];
    header("Location: ../../Website/HTML/Transição.html"); 
} else {
    //Caso o email/senha não exista, imprime erro na url
   header("Location: ../HTML/Login.html?erro=1");
    exit;
}
?>